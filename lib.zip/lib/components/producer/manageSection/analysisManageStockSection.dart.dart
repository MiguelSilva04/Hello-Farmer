import 'package:flutter/material.dart';

class AnalysisManageStockSection extends StatelessWidget {
  const AnalysisManageStockSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text("A.Stock"));
  }
}
