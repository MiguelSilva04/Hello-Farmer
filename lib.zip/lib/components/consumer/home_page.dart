import 'package:flutter/material.dart';

class ConsumerHomePage extends StatelessWidget {
  const ConsumerHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Inicio"));
  }
}
